<?php
    include_once'db/connect_db.php';
    session_start();
    if($_SESSION['username']==""){
        header('location:index.php');
    }else{
        if($_SESSION['role']=="Admin"){
          include_once'inc/header_all.php';
        }else{
            include_once'inc/header_all_operator.php';
        }
    }

    error_reporting(0);

    $id = $_GET['id'];
	
	 $delete = $pdo->prepare("DELETE FROM interview_candidates WHERE id=".$id);

    if($delete->execute()){
        echo'<script type="text/javascript">
            jQuery(function validation(){
            swal("Info", "User Has Been Deleted", "info", {
            button: "Continue",
                });
            });
            </script>';
    }

   
?>

<html>
<head>
<meta>

<style>
th:nth-child(1) input,th:nth-child(2) input,th:last-child input{  
	display:none !important;
}
th input{
	padding:6px;
	font-weight:500;
	font-size:12px;
}
</style>


 
</head>
</html>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) 
    <section class="content-header">
      <h1>
        Candidates
      </h1>
      <hr>
    </section>-->

    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
            <div class="box-header with-border border-1">
                <h2  class="box-title list-h">Candidates List</h2>
                <!-- <a href="add_candidate.php" class="btn btn-success btn-sm pull-right">Add candidates</a> -->
            </div>
            <div class="box-body">				
                <div style="overflow-x:auto;">
                    <table class="table table-striped" id="myCandidates">
                        <thead>
                            <tr>
                                <th style="width:20px;">Candidate ID</th>
								<!--<th style="width:100px;">Image</th>-->
                                <th style="width:140px;">Candidate Name</th>
								 <th style="width:100px;">Email</th>
                                <th style="width:100px;">Mobile Number</th>
                                <th style="width:60px;">Domain</th>
								 <th style="width:100px;">Level of Experiance</th>
								 <th style="width:100px;">Location</th>								
								<th style="width:100px;">ID Proof Type</th>
								<th style="width:100px;">ID Proof Number</th>
                                <th style="width:100px;">In Time</th>								
                                <th style="width:50px;">Interviewer Name</th>
								<th style="width:50px;">Options</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            $select = $pdo->prepare("SELECT * FROM interview_candidates");
                            $select->execute();
                            while($row=$select->fetch(PDO::FETCH_OBJ)){
                            ?>
                                <tr>
                                <td><?php echo $row->id; ?></td>
								<!--<td><img src="<?php echo $row->emp_image?>" alt="Product Image" class="img-responsive" style="height:40px;"></td>-->
								<td class="text-uppercase"><?php echo $row->candidate_name; ?></td>
								<td><?php echo $row->email; ?></td>								
                                <td ><?php echo $row->mobile; ?></td>
                                <td><?php echo $row->technology; ?></td>
								<td><?php echo $row->category; ?></td>
								<td><?php echo $row->location; ?></td>
								<td><?php echo $row->id_type; ?></td>
								<td><?php echo $row->id_number; ?></td>
								<td><?php echo $row->in_time; ?></td>							 
								<td><?php echo $row->schdule_name; ?></td>
								 <td>
                                    <?php if($_SESSION['role']=="Admin"){ ?>
                                    <a href="candidates.php?id=<?php echo $row->id ; ?>" onclick="return confirm('Are u sure to delete?')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                    <?php } ?>
									
									<a href="candidate-print.php?id=<?php echo $row->id; ?>" target="_blank" class="btn btn-info btn-sm"><i class="fa fa-print"></i></a>
                                    
                                </td>
                              
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
				
                </div>
				
				
				
				
				
				<br />
				<p class="text-center"><a href="javascript:void(0);" class="btn btn-primary" onclick="printPage();">Print Records</a> </p>
            </div>

        </div>


    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script type="text/javascript">
 function printPage(){
		
        var tableData = '<table border="1">'+document.getElementsByTagName('table')[0].innerHTML+'</table>';
		 var firsrow = 	tableData;	
		
        var data = '<button onclick="window.print()">Print this page</button>'+firsrow;   
		
        myWindow=window.open('','','width=800,height=600');
        myWindow.innerWidth = screen.width;
        myWindow.innerHeight = screen.height;
        myWindow.screenX = 0;
        myWindow.screenY = 0;
        myWindow.document.write(data);
        myWindow.focus();
    };
 </script>




   <script>
  $(document).ready(function() {
     $('#myCandidates thead tr').clone(true).appendTo( '#myCandidates thead' );
    $('#myCandidates thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
	  var table = $('#myCandidates').DataTable( {
        orderCellsTop: true,
        fixedHeader: true
    } );
  });
	
 
  </script>
 <?php
    include_once'inc/footer_all.php';
 ?>