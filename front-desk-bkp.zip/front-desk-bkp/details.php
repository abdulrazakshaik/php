<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>-->

<?php

   $servername='localhost';
    $username='root';
    $password='Ojas1525';
    $dbname = "ojas_frontdesk";
    $conn=mysqli_connect($servername,$username,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
	session_start();
   if($_SESSION['username']==""){
     include_once'inc/404.php';
   }else{
     if($_SESSION['role']=="Admin"){
       include_once'inc/header_all.php';
     }else{
         include_once'inc/header_all_operator.php';
     }
   }
   
   if(isset($_POST['save_candidate'])){ 
	include_once 'db/insertCandidates.php';
   }
   
   if(isset($_POST['save_visitor'])){ 
	include_once 'db/insertVisitors.php';
   }
   
    if(isset($_POST['save_vendor'])){ 
	include_once 'db/insertVendor.php';
   }
   
?>

<html>
<head>
<meta>

<style>
th:nth-child(1) input,th:last-child input{  
	display:none !important;
}
th input{
	padding:6px;
	font-weight:500;
	font-size:12px;
}
</style> 
</head>
</html>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) 
    <section class="content-header">
      <h1>
        Candidates
      </h1>
      <hr>
    </section>-->
    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
            <div class="box-header with-border">
			<div class="box-body">
               <section>	
					<div class="form-group col-md-3">
					<label for="" class="padding-all">Purpose of Visit</label>
					<select class="form-control detailss" id="detailss" name="detailss">					
					<option value="interview">Interview</option>
					<option value="visitor">Visitor</option>
					<option value="vendor">Vendor</option>                               
               </select>	
			 </div>
				</section>
				</div>
            </div>
            <div class="box-body">
		<section class="">	
        <div class="box box-success border-none" id="interview">
          <form action="" method="POST" enctype="multipart/form-data">		  
			<div class="box-body">			
			  <h4 class="list-head">Candidate Details</h4>
			  <br>
		
			   <div class="form-group col-md-3">
                  <label>Candidate Name <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" name="candidate_name" id="candidate_name" value="<?php echo isset($_POST['candidate_name']) ? $_POST['candidate_name'] : '' ?>" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Email <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="email" class="form-control pull-right" name="email" id="email" required value="<?php echo isset($_POST['email']) ? $_POST['email'] : '' ?>">
                  </div>
                  <!-- /.input group -->
                </div>				
				
                <div class="form-group col-md-3">
                  <label>Mobile Number <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" name="mobile" id="mobile"  maxlength="10" minlength="10" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				     <div class="form-group col-md-3" id="otpvalid">
                  <label>Enter valid OTP <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" name="otp" id="otp" required>
                  </div>
                </div>
				
				
				
                <div class="form-group col-md-3">
                  <label>Technology <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" name="technology" id="technology" required value="<?php echo isset($_POST['technology']) ? $_POST['technology'] : '' ?>"> 
                  </div>
                  <!-- /.input group -->
                </div>
				
				 <div class="form-group col-md-3">
                  <label>Scheduled Name <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" name="schdule_name" id="schdule_name" required value="<?php echo isset($_POST['schdule_name']) ? $_POST['schdule_name'] : '' ?>">
                  </div>
                  <!-- /.input group -->
                </div>	 
			 
				<div class="form-group col-md-3">
                  <label>In Time <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="time" value="<?php
					date_default_timezone_set('Asia/Kolkata');
					echo date('H:i:s'); ?>" class="form-control pull-right" name="in_time" id="in_time" required value="<?php echo isset($_POST['in_time']) ? $_POST['in_time'] : '' ?>">
                  </div>
                  <!-- /.input group -->
                </div>	
			 
			 
			 <div class="form-group col-md-3">
                            <label for="">Experience <span class="warning-color">*</span></label>
                            <select class="form-control category"  id="category" name="category" required value="<?php echo isset($_POST['category']) ? $_POST['category'] : '' ?>">
									<option >Enter option</option>
									<option>Fresher</option>
									<option>Experience</option>                               
                            </select>
                        </div>
					<div class="form-group col-md-3" id="experience">
                  <label>Year's of Experience <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" value="0" name="experience" id="experience" required value="<?php echo isset($_POST['experience']) ? $_POST['experience'] : '' ?>">
                  </div>
                  <!-- /.input group -->
                </div>
				
				
				 <div class="form-group col-md-3">
                            <label for="">Type of Vehical <span class="warning-color">*</span></label>
                            <select class="form-control typevehical"  id="vehical" name="vehical" required value="<?php echo isset($_POST['vehical']) ? $_POST['vehical'] : '' ?>">
									<option>Enter option</option>
									<option>Two</option>
									<option>Four</option>
									<option>No Vehical</option>
                               
                            </select>
                        </div>
				
				
						
				<div class="form-group col-md-3" id="vehical_number">
                  <label>Vehical Number <span class="warning-color">*</span></label>
                  <div class="">                    
				<input type="text" class="form-control pull-right" value="0" name="vehical_number" id="vehical_number" required value="<?php echo isset($_POST['vehical_number']) ? $_POST['vehical_number'] : '' ?>">
                  </div>
                  <!-- /.input group -->
                </div> 
				
				
				 <div class="form-group col-md-3">
                  <label>Location <span class="warning-color">*</span></label>
                  <div class="">                   
                    <input type="text" class="form-control pull-right" name="location" id="location" required value="<?php echo isset($_POST['location']) ? $_POST['location'] : '' ?>">
                  </div>
                  <!-- /.input group -->
                </div>		 	
				
				<div class="form-group col-md-3">
                            <label for="">Select Id Proof <span class="warning-color">*</span></label>
                            <select class="form-control id_proof"  id="id_type" name="id_type" required value="<?php echo isset($_POST['id_type']) ? $_POST['id_type'] : '' ?>">
									<option value="select">Select id Proof</option>
									<option value="aadhaar">Aadhaar</option>
									<option value="pan">Pan</option>
									<option value="driving_licence">Driving Licence</option>
									<option value="passport">Passport</option>
                               
                            </select>
                        </div>	
					
				<div class="col-md-3 form-group" id="id_file">
                    <label for="">ID Proof</label><br>               
                    <input type="file" class="" id="id_proof" name="id_proof" > <br>
                      
						  <!-- /.input group -->
                    </div>					
					
				<div class="form-group col-md-3" id="id_num">
					<label>ID Proof Number <span class="warning-color">*</span></label>
						<div class="">							
							<input type="text" class="form-control pull-right" name="id_number" id="id_number" required value="<?php echo isset($_POST['id_number']) ? $_POST['id_number'] : '' ?>">
						</div>
                  <!-- /.input group -->
                </div>	



				       
				
		
				</div>			
                 

		
				<div class="box-body">
				<div class="form-group col-md-2">
				<label>Candidate Image </label>
                <div id="my_camera"></div>
                <br/>
                <input type=button value="Take Snapshot" onClick="take_snapshot()" >
                <input type="hidden" name="emp_image" class="image-tag" >
            </div>
				
			
            <div class="col-md-4">
                <div style="margin-bottom:10px;">Your captured image will appear here...</div>
                <div id="results" name="emp_image"></div>
            </div>				
				 
              </div>  

		  
			<br><br>			
            <div class="box-footer" align="center">
              <input type="submit" name="save_candidate" value="Save Candidate" class="btn btn-success">
              <a href="candidates.php" class="btn btn-warning">Back</a>
            </div>
          </form>		  
        </div>	
		
		<div class="box box-success border-none" id="visitor">
          <form action="" method="POST" enctype="multipart/form-data" >           
			<div class="box-body">		
             
			  <h4 class="list-head">Visitor Details</h4>
			  <br>
			  
			
			   <div class="form-group col-md-3">
                  <label>Visitor Name<span class="warning-color">*</span></label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="visitor_name" id="visitor_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				
                <div class="form-group col-md-3">
                  <label>Mobile Number<span class="warning-color">*</span></label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="mobile" id="mobile" required max="10">
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Purpose of Visit<span class="warning-color">*</span></label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="purpose" id="purpose" required>
                  </div>
                  <!-- /.input group -->
                </div>
				  <!--<div class="form-group col-md-3">
                  <label>ID Proof</label>
                  <div class="">
                    <div class="-addon">
                      <span>proof</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="id_proof" id="id_proof" required>
                  </div>
                </div>-->  
				<div class="form-group col-md-3">
                  <label>Whom to meet<span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" name="meeting_person" id="meeting_person" required >
                  </div>
                  <!-- /.input group -->
                </div>				
				<div class="form-group col-md-3">
                  <label>In Time</label>                
				  <div class="">                    
                    <input type="time" value="<?php
					date_default_timezone_set('Asia/Kolkata');
					echo date('H:i:s'); ?>" class="form-control pull-right" name="in_time" id="in_time" required >
                  </div>
                  <!-- /.input group -->
                </div>				
				<div class="form-group col-md-3">
                            <label for="">Type of Vehical</label>
                            <select class="form-control visitorVehical"  id="vehical_type" name="vehical_type">
									<option value="NULL">Enter option</option>
									<option value="two">Two</option>
									<option value="four">Four</option>
									<option value="ten">No Vehical</option>
                             </select>
                        </div>					
				
				 <div class="form-group col-md-3" id="visitorVehical">
                  <label>vehical Number</label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" value = "0" name="vehical_number" 
			id="vehical_number" required style="text-transform:uppercase">
                  </div>
                  <!-- /.input group -->            
				
              </div>
			  
					<div class="form-group col-md-3">
                            <label for="">Select Id Proof <span class="warning-color">*</span></label>
                            <select class="form-control visitors_id_proof"  id="id_type" name="id_type" required>
									<option value="select">Select id Proof</option>
									<option value="aadhaar">Aadhaar</option>
									<option value="pan">Pan</option>
									<option value="driving_licence">Driving Licence</option>
									<option value="passport">Passport</option>                               
                            </select>
                        </div>			
			   
			    <div class="form-group col-md-3" id="visitor_id_proof">
                        <div class="form-group">
                            <label for="">ID Proof</label><br>
                            
                            <input type="file" class="" id="id_proof"
                            name="id_proof"> <br>
                        </div>
						  <!-- /.input group -->
                    </div>					
					<div class="form-group col-md-3" id="visitor_id_num">
					<label>ID Proof Number <span class="warning-color">*</span></label>
						<div class="">							
							<input type="text" class="form-control pull-right" name="id_number" id="id_number" required>
						</div>
                  <!-- /.input group -->
                </div>				
              </div>        
			<br><br>			
            <div class="box-footer" align="center">
              <input type="submit" name="save_visitor" value="Save Candidate" class="btn btn-success">
              <a href="visitor.php" class="btn btn-warning">Back</a>
            </div>
          </form>
        </div>
		
		<div class="box box-success border-none" id="vendor">
          <form action="" method="POST" enctype="multipart/form-data">
		  <div class="box-body">			 
			  <h4 class="list-head">Vendor Info</h4>
			  <br>			  
			    <div class="form-group col-md-3">
                            <label>Vendor Type <span class="warning-color">*</span></label>
							 <select class="form-control vendorname"  id="vendorname" name="vendorname" >
									<option>Select Vendor Type</option>
									<option>Old Vendor</option>
									<option>New Vendor</option>
                            </select>
							
                        </div>
						</div>
		  <div class="box-body">			 
			 			  
			  
			  <div class="form-group col-md-3">
                  <label>Company Name <span class="warning-color">*</span></label>
                  <div class="">                   
                    <input type="text" class="form-control pull-right" name="company_name" id="company_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
			  
			    
			  
			  
			   <div class="form-group col-md-3 " id="">
                  <label>Vendor Name <span class="warning-color">*</span></label>
                  <div class="">
                    <input type="text" class="form-control" name="vendor_name" id="vendor_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
               
			   <div class="form-group col-md-3">
                  <label>Mobile <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control" name="mobile" id="mobile" required>
                  </div>
                  <!-- /.input group -->
                </div>
                
				
			
				<div class="form-group col-md-3">
                  <label>In Time <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="time" value="<?php
					date_default_timezone_set('Asia/Kolkata');
					echo date('H:i:s'); ?>" class="form-control pull-right" name="in_time" id="in_time" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Products <span class="warning-color">*</span></label>
                  <div class="">                   
                    <input type="text" class="form-control pull-right" name="products" id="products" required>
                  </div>
                  <!-- /.input group -->
                </div>
               
			   
			   <div class="form-group col-md-3">
                  <label>Delivery Date <span class="warning-color">*</span></label>
                  <div class="">
                    
                    <input type="date" class="form-control pull-right" name="delivery_date" id="delivery_date" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				 <div class="col-md-3 form-group">
                            <label>DC Attachment </label><br>                            
                            <input type="file" class="form-control pull-right" id="dc_attachment"
                            name="dc_attachment"> <br>
                        
						  <!-- /.input group -->
                 </div>	
			   
			   <div class="form-group col-md-3">
                  <label>DC No <span class="warning-color">*</span></label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="dc_no" id="dc_no" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				
				
				
					
					<div class="col-md-3 form-group">
                            <label>Invoice Attachment</label><br>                            
                            <input type="file" class="form-control pull-right" id="invoice_attachment"
                            name="invoice_attachment"> <br>
                        
						  <!-- /.input group -->
                 </div>	
				
				<div class="form-group col-md-3">
                  <label>Invoice Number <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" name="invoice_number" id="invoice_number" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				
				
				<div class="form-group col-md-3">
                  <label>Receiver <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" name="receiver" id="receiver" required>
                  </div>
                  <!-- /.input group -->
                </div> 
				
				<div class="form-group col-md-3">
                  <label>Department <span class="warning-color">*</span></label>
                  <div class="">
                    <input type="text"  class="form-control pull-right" name="department" id="department" required>
                  </div>
                  <!-- /.input group -->
                </div>	
				
				<div class="form-group col-md-3">
                  <label>Whom to Deliver <span class="warning-color">*</span></label>
                  <div class="">
                    <input type="text" class="form-control pull-right" name="deliver_person" id="deliver_person" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Quantity <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="number" class="form-control pull-right" name="quantity" id="quantity" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				 <div class="form-group col-md-3">
                            <label>Type of Vehical <span class="warning-color">*</span></label>
                            <select class="form-control vendorVehical"  id="vehical_type" name="vehical_type" required>
									<option value="NULL">Enter option</option>
									<option value="two">Two</option>
									<option value="four">Four</option>
									<option value="ten">No Vehical</option>                               
                            </select>
                        </div>
				
				 <div class="form-group col-md-3" id="vendorVehical">
                  <label>vehical Number <span class="warning-color">*</span></label>
                  <div class="">                    
                    <input type="text" class="form-control pull-right" value="0" name="vehical_number" id="vehical_number" required style="text-transform:uppercase">
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                            <label for="">Select Id Proof <span class="warning-color">*</span></label>
                            <select class="form-control vendors_id_proof"  id="id_type" name="id_type" required>
									<option value="select">Select id Proof</option>
									<option value="aadhaar">Aadhaar</option>
									<option value="pan">Pan</option>
									<option value="driving_licence">Driving Licence</option>
									<option value="passport">Passport</option>
                               
                            </select>
                        </div>	
				
				
				 <div class="col-md-3 form-group" id="vendor_id_proof">
                        <div class="">
                            <label>ID Proof</label><br>
                            
                            <input type="file" class="form-control pull-right" id="id_proof"
                            name="id_proof" > <br>
                        </div>
						  <!-- /.input group -->
                    </div>
					
					<div class="form-group col-md-3" id="vendor_id_num">
					<label>ID Proof Number <span class="warning-color">*</span></label>
						<div class="">							
							<input type="text" class="form-control pull-right" name="id_number" id="id_number" required>
						</div>
                  <!-- /.input group -->
                </div>
              </div>
            
           
           	 
						
			<br><br>
			  <div class="box-footer" align="center">
              <input type="submit" name="save_vendor" value="Save vendor" class="btn btn-success">
              <a href="vendor.php" class="btn btn-warning">Back</a>
            </div>
          </form>
          
        </div>
	</section>
            </div>

        </div>


    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
 <script>
  $(document).ready(function() {
  	$("#interview").show();
	$("#visitor").hide();
	$("#vendor").hide();
			const selectElement = document.querySelector('.detailss');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "interview"){
				$("#interview").show();
				$("#visitor").hide();
			}
			else if(category == "visitor"){
				$("#visitor").show();
				$("#interview").hide();
				$("#vendor").hide();
			}
			
			else if(category == "vendor"){
				$("#interview").hide();
				$("#visitor").hide();
				$("#vendor").show();
			}
			else{
				$("#interview").hide();
				$("#visitor").hide();
				$("#vendor").hide();
			}
						
});
  });
	
 
  </script>
  
  
    <script type="text/javascript">
    $(document).ready(function(){ 
			$("#vendor_id_num").hide();
			$("#vendor_id_proof").hide();
			const selectElement = document.querySelector('.vendors_id_proof');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "aadhaar" || category == "pan" || category == "driving_licence" || category == "passport"){
				
				$("#vendor_id_num").show();
			$("#vendor_id_proof").show();
			}			
			else{
				$("#vendor_id_num").hide();
			$("#vendor_id_proof").hide();
			}			
		
});
    });
  </script>
  
 
  
  
  
  <script type="text/javascript">
    $(document).ready(function(){ 
			$("#visitor_id_num").hide();
			$("#visitor_id_proof").hide();
			const selectElement = document.querySelector('.visitors_id_proof');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "aadhaar" || category == "pan" || category == "driving_licence" || category == "passport"){
				
				$("#visitor_id_num").show();
			$("#visitor_id_proof").show();
			}			
			else{
				$("#visitor_id_num").hide();
			$("#visitor_id_proof").hide();
			}			
		
});
    });
  </script>
  
  
    <script type="text/javascript">
    $(document).ready(function(){ 
			$("#id_num").hide();
			$("#id_file").hide();
			const selectElement = document.querySelector('.id_proof');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "aadhaar" || category == "pan" || category == "driving_licence" || category == "passport"){
				$("#id_num").show();
				$("#id_file").show();
			}			
			else{
				$("#id_num").hide();
				$("#id_file").hide();
			}			
		
});
    });
  </script>
 
  
  
    <script type="text/javascript">
    $(document).ready(function(){ 
			$("#experience").hide();
			const selectElement = document.querySelector('.category');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "Experience"){
				$("#experience").show();
			}			
			else{
				$("#experience").hide();
			}			
		
});
    });
  </script>
  
   <script type="text/javascript">
    $(document).ready(function(){ 
			$("#vendorVehical").hide();
			const selectElement = document.querySelector('.vendorVehical');
			selectElement.addEventListener('change', (event) => {
			var valueee = event.target.value;
			if(valueee == "two" || valueee == "four"){
				$("#vendorVehical").show();
			}
			else if(valueee == "ten"){
				$("#vendorVehical").hide();
			}			
			else{
				$("#vendorVehical").hide();
			}
			
		
});
    });
  </script>
  
  <script type="text/javascript">
    $(document).ready(function(){ 
			$("#visitorVehical").hide();
			const selectElement = document.querySelector('.visitorVehical');
			selectElement.addEventListener('change', (event) => {
			var valueee = event.target.value;
			if(valueee == "two" || valueee == "four"){
				$("#visitorVehical").show();
			}
			else if(valueee == "ten"){
				$("#visitorVehical").hide();
			}			
			else{
				$("#visitorVehical").hide();
			}
					
});
    });
  </script>
  
   <script type="text/javascript">
    $(document).ready(function(){ 
			$("#vehical_number").hide();
			const selectElement = document.querySelector('.typevehical');
			selectElement.addEventListener('change', (event) => {
			var valueee = event.target.value;
			if(valueee == "Two" || valueee == "Four"){
				$("#vehical_number").show();
			}
			else if(valueee == "No Vehical"){
				$("#vehical_number").hide();
			}
			
			else{
				$("#vehical_number").hide();
			}		
		
});
    });
  </script>
  
  
  
   <script type="text/javascript">
    $(document).ready(function(){ 
			$("#vendorname1").hide();
			const selectElement = document.querySelector('.vendorname');
			selectElement.addEventListener('change', (event) => {
			var valueee = event.target.value;
			if(valueee == "New Entry"){
				$("#vendorname1").show();
			}
			else{
				$("#vendorname1").hide();
			}		
		
});
    });
  </script>
  
  <script type="text/javascript">
  $('#otpvalid').hide();

  $('#mobile').keyup(function() {
    var dInput = this.value;
	
   if(dInput.length == 10){
	    $('#otpvalid').show();
	   ajaxCall(dInput);	   
   }
});


  function ajaxCall(dInput) {
	$.ajax({
   type: "get",
   url: "otpvalidation.php?mobile=" + dInput, 
   success: (function (data) {
	  var response = data;
	  alert("Please enter valid OTP ");
    })
    })

};


  </script>
  
  
  <script>
  //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  
  </script>
  
    <script language="JavaScript">
    Webcam.set({
        width: 200,
        height: 150,
		image_format: 'jpg',
        jpeg_quality: 250	
    });
  
    Webcam.attach( '#my_camera' );
  
    function take_snapshot() {
        Webcam.snap( function(data_uri) {
            $(".image-tag").val(data_uri);
            document.getElementById('results').innerHTML = '<img src="'+data_uri+'"/>';
        } );
    }
</script>
  
   
 <?php
    include_once'inc/footer_all.php';
 ?>