<?php

 $servername='localhost';
    $username='root';
    $password='';
    $dbname = "employee_registration";
    $conn=mysqli_connect($servername,$username,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
		
		
		
    session_start();
   if($_SESSION['username']==""){
     include_once'inc/404.php';
   }else{
     if($_SESSION['role']=="Admin"){
       include_once'inc/header_all.php';
     }else{
         include_once'inc/header_all_operator.php';
     }
   }

 
if(isset($_POST['save_vendor'])){  
	  $vendor_name = $_POST['vendor_name'];
      $mobile = $_POST['mobile'];	 
      $company_name = $_POST['company_name'];
	  
	  $products = $_POST['products'];
	  $delivery_date = $_POST['delivery_date'];
	  $dc_no = $_POST['dc_no'];
	  $invoice_number = $_POST['invoice_number'];
	  $receiver = $_POST['receiver'];
	  $department = $_POST['department'];
	  
	  $deliver_person = $_POST['deliver_person'];
	  $quantity = $_POST['quantity'];
	  $vehical_number = $_POST['vehical_number'];
		 
	    
	   $up_file=$_FILES["id_proof"]["name"];
        move_uploaded_file($_FILES["id_proof"]["tmp_name"],"upload/".$up_file);
		
		$dc_attachment=$_FILES["dc_attachment"]["name"];
        move_uploaded_file($_FILES["dc_attachment"]["tmp_name"],"upload/".$dc_attachment);
		
		$invoice_attachment=$_FILES["invoice_attachment"]["name"];
        move_uploaded_file($_FILES["invoice_attachment"]["tmp_name"],"upload/".$invoice_attachment);
	   
	 
	  $sql = "INSERT INTO vendor_details (vendor_name, mobile, company_name, id_proof, products, delivery_date, dc_no, dc_attachment ,invoice_number, invoice_attachment, receiver, department, deliver_person, quantity, vehical_number)
		VALUES ('$vendor_name', '$mobile', '$company_name', '$up_file', '$products', '$delivery_date', '$dc_no','$dc_attachment', '$invoice_number','$invoice_attachment', '$receiver' , '$department' , '$deliver_person' , '$quantity' , '$vehical_number')";
			if (mysqli_query($conn, $sql)) {
				echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "New User Added", "success", {
                        button: "Continue",
                            });
                        });
                        </script>';
			} else {
				echo "Error: " . $sql . ":-" . mysqli_error($conn);
			}
	  
     mysqli_close($conn);
	  //echo '<script>location.href="order.php";</script>';
}
 
	
	
	 

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Vendor
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
          <form action="" method="POST" enctype="multipart/form-data">
		  
          
			
			<div class="box-body">
			
              <div class="col-md-12">
			  <h4>Vendor Info</h4>
			  <br>
			   <div class="form-group col-md-3">
                  <label>Vendor Name</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Name</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="vendor_name" id="vendor_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Mobile</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Mobile</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="mobile" id="mobile" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Company Name</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Compnay</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="company_name" id="company_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
			
				
				 <div class="col-md-3">
                        <div class="form-group">
                            <label for="">ID Proof</label><br>
                            
                            <input type="file" class="input-group" id="id_proof"
                            name="id_proof" > <br>
                        </div>
						  <!-- /.input group -->
                    </div>
               
              </div>
            </div>
            <div class="box-body">
              <div class="col-md-12">

			<div class="form-group col-md-3">
                  <label>Products</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>parts</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="products" id="products" required>
                  </div>
                  <!-- /.input group -->
                </div>
				

	
			   <div class="form-group col-md-3">
                  <label>Delivery Date</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>date</span>
                    </div>
                    <input type="date" class="form-control pull-right" name="delivery_date" id="delivery_date" required>
                  </div>
                  <!-- /.input group -->
                </div>

				<div class="form-group col-md-3">
                  <label>DC no</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>DC No</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="dc_no" id="dc_no" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				 
	

				<div class="col-md-3 form-group">
                            <label for="">DC Attachment</label><br>
                            
                            <input type="file" class="input-group" id="dc_attachment"
                            name="dc_attachment"> <br>
                        
						  <!-- /.input group -->
                 </div>				
             
              </div>
            </div>
			
			
			 <div class="box-body">
              <div class="col-md-12">	
			  
			   <div class="form-group col-md-3">
                  <label>Invoice Number</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Invoice</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="invoice_number" id="invoice_number" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="col-md-3 form-group">
                            <label for="">Invoice Attachment</label><br>
                            
                            <input type="file" class="input-group" id="invoice_attachment"
                            name="invoice_attachment"> <br>
                        
						  <!-- /.input group -->
                 </div>	

				<div class="form-group col-md-3">
                  <label>Receiver</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Receiver</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="receiver" id="receiver" required>
                  </div>
                  <!-- /.input group -->
                </div> 
				
				
                 <div class="form-group col-md-3">
                  <label>Department</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>department</span>
                    </div>
                    <input type="text"  class="form-control pull-right" name="department" id="department" required>
                  </div>
                  <!-- /.input group -->
                </div>		
		
                             
              </div>
            </div>	


	 <div class="box-body">
              <div class="col-md-12">	
			  
			   <div class="form-group col-md-3">
                  <label>Whom to Deliver</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>deliver</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="deliver_person" id="deliver_person" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				

				 
				 <div class="form-group col-md-3">
                  <label>Quantity</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>quantity</span>
                    </div>
                    <input type="number" class="form-control pull-right" name="quantity" id="quantity" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				
                <div class="form-group col-md-3">
                  <label>vehical Number</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Vehicle</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="vehical_number" id="vehical_number" required style="text-transform:uppercase">
                  </div>
                  <!-- /.input group -->
                </div>	
		
                             
              </div>
            </div>				


     
			<br><br>
			
            <div class="box-footer" align="center">
              <input type="submit" name="save_vendor" value="Save vendor" class="btn btn-success">
              <a href="vendor.php" class="btn btn-warning">Back</a>
            </div>
          </form>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


  <script>
  //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  
  </script>
  
  <script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#img_preview').attr('src', e.target.result)
                .width(250)
                .height(200);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
  
  


 <?php
    include_once'inc/footer_all.php';
 ?>