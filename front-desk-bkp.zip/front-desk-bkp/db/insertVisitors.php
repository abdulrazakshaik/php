<?php


     $visitor_name = $_POST['visitor_name'];
      $mobile = $_POST['mobile'];	 
      $purpose = $_POST['purpose']; 
      $in_time = $_POST['in_time'];

$id_type = $_POST['id_type'];
 $id_number = $_POST['id_number'];	  
     $str = $mobile;
		$pattern = "/^[1-9]{1}[0-9]{9}$/";
		$mobilevalidation=  preg_match($pattern, $str);
		$vehical_type = $_POST['vehical_type'];	  
      $vehical_number = $_POST['vehical_number'];	  
	  $meeting_person = $_POST['meeting_person'];
	  
	  $up_file=$_FILES["id_proof"]["name"];
        move_uploaded_file($_FILES["id_proof"]["tmp_name"],"upload/".$up_file);
	   if($mobilevalidation != 1){
		  echo'<script type="text/javascript">
                    jQuery(function validation(){
                    swal("Warning", "Enter valid mobile number", "warning", {
                    button: "Continue",
                        });
                    });
                    </script>';
	  }else{
     $sql = "INSERT INTO visitor_details (visitor_name, mobile, purpose, id_proof, meeting_person,in_time,vehical_type,vehical_number,id_type,id_number)
     VALUES ('$visitor_name','$mobile','$purpose','$up_file','$meeting_person','$in_time','$vehical_type','$vehical_number','$id_number','$id_type' )";
 
     if (mysqli_query($conn, $sql)) {
        echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "New User Added", "success", {
                        button: "Continue",
                            });
                        });
                        </script>';
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
	  }

	
     mysqli_close($conn);
	  //echo '<script>location.href="order.php";</script>';

?>



