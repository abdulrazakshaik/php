<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script> -->




<?php

    error_reporting(0);
	

    $candidate_name = $_POST['candidate_name'];
    $mobile = $_POST['mobile'];	 
     $technology = $_POST['technology'];
	 $email = $_POST['email'];
	 $category = $_POST['category'];
	 $location = $_POST['location'];
	 $id_number = $_POST['id_number'];
	 $experience = $_POST['experience'];	 	
	 $in_time = $_POST['in_time'];
	 //$out_time = $_POST['out_time'];
	 $schdule_name = $_POST['schdule_name'];
	 $id_type = $_POST['id_type'];
	 $emp_image = $_POST['emp_image'];	  
	  $vehical = $_POST['vehical'];	  
	  $vehical_number = $_POST['vehical_number'];
	  
	  $otp = $_POST['otp'];
	  
	  

	$str = $mobile;
		$pattern = "/^[1-9]{1}[0-9]{9}$/";
		$mobilevalidation=  preg_match($pattern, $str);

	  
	        $folderPath = "upload/";  
			$image_parts = explode(";base64,", $emp_image);
			$image_type_aux = explode("image/", $image_parts[0]);
			$image_type = $image_type_aux[1];  
			$image_base64 = base64_decode($image_parts[1]);
			$fileName = uniqid() . '.png';  
			$file = $folderPath . $fileName;
			file_put_contents($file, $image_base64); 
			file_put_contents('img.png', base64_decode($base64string));
	  
	    $up_file=$_FILES["id_proof"]["name"];
        move_uploaded_file($_FILES["id_proof"]["tmp_name"],"upload/".$up_file);

		
	  if($mobilevalidation != 1){
		  echo'<script type="text/javascript">
                    jQuery(function validation(){
                    swal("Warning", "Enter valid mobile number", "warning", {
                    button: "Continue",
                        });
                    });
                    </script>';
	  }else{
		  
		 $var_value = $_SESSION['randomnumber'];
		if($otp == $var_value){
		   $sql = "INSERT INTO interview_candidates (candidate_name, email,mobile, technology,category,location, id_proof,id_number, in_time,schdule_name,experience,vehical,vehical_number,emp_image,id_type,otp)
     VALUES ('$candidate_name','$email','$mobile','$technology','$category','$location','$up_file','$id_number','$in_time','$schdule_name','$experience','$vehical','$vehical_number','$file','$id_type','$otp')";
 
     if (mysqli_query($conn, $sql)) {
        echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "interviewer Added", "success", {
                        button: "Continue",
                            });
                        });
						 window.location.assign("http://frontdesk.corp.ojas-it.com:9988/ojas-frontdesk/dashboard.php");
                        </script>';
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
		}
		else{
			  echo'<script type="text/javascript">
              jQuery(function validation(){
              swal("OTP is wrong", "OTP is mismatched!", "error" );
              });
          </script>';
		}
		
	  }
    
     mysqli_close($conn);
	 
	 
	 	/*$rand_number = rand(1000,9999);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://api.textlocal.in/send/?apikey=9iyzy1tw/Jg-IOKHoXx5A4TMBLxwjLYiYKnZSVmDCy&sender=OJASIT&numbers=9059899336&message=" . urlencode("Your OTP for Validation is ".$rand_number));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET"); 

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 20);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 25);

curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)');

$response = curl_exec($ch);

$info = curl_getinfo($ch);


curl_close ($ch);

return $response;*/
	 

?>

<style>

.modal-body { 
  h1 { 
    font-weight:900; 
    font-size:2.3em;
    text-transform:uppercase;
  }
  
  a.pre-order-btn { 
    color:#000;
    background-color:gold;
    border-radius:1em;
    padding:1em;
    display: block;
    margin: 2em auto;
    width:50%;
    font-size:1.25em;
    font-weight:6600;
    &:hover { 
    background-color:#000;
      text-decoration:none;
      color:gold;
    }
  }
  
  
}

</style>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <!--         <h4 class="modal-title">Modal Header</h4> -->
      </div>
      <div class="modal-body text-center">
        <h1>Full screen Transparent Bootstrap Modal</h1>
        <p>FEEL FRREE TO GET YOUR MODAL CODE HERE FOLKS.</p>
        <a class="pre-order-btn" href="#">GET THE MODAL CODE</a>
      </div>
      <div class="modal-footer">
        <!--         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
      </div>
    </div>

  </div>
</div>

<script>

$(document).ready(function(){       
   $('#myModal').modal('show');
    }); 
	</script>





