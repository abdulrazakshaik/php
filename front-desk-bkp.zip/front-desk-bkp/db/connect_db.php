<?php

try{
    $pdo = new PDO('mysql:host=localhost;dbname=ojas_frontdesk','root','Ojas1525');
    //echo 'Connection Successfull';
}catch(PDOException $error){
    echo $error->getmessage();
}


?>