<?php


    $vendor_name = $_POST['vendor_name'];
      $mobile = $_POST['mobile'];	 
      $company_name = $_POST['company_name'];
	  
	  $products = $_POST['products'];
	  $delivery_date = $_POST['delivery_date'];
	  $dc_no = $_POST['dc_no'];
	  $invoice_number = $_POST['invoice_number'];
	  $receiver = $_POST['receiver'];
	  $department = $_POST['department'];
	  
	  $deliver_person = $_POST['deliver_person'];
	  $quantity = $_POST['quantity'];
	  $vehical_number = $_POST['vehical_number'];
	  $vehical_type = $_POST['vehical_type'];
		 $in_time = $_POST['in_time']; 
	 

$str = $mobile;
		$pattern = "/^[1-9]{1}[0-9]{9}$/";
		$mobilevalidation=  preg_match($pattern, $str);
$id_type = $_POST['id_type'];
 $id_number = $_POST['id_number'];	
 
	    
	   $up_file=$_FILES["id_proof"]["name"];
        move_uploaded_file($_FILES["id_proof"]["tmp_name"],"upload/".$up_file);
		
		$dc_attachment=$_FILES["dc_attachment"]["name"];
        move_uploaded_file($_FILES["dc_attachment"]["tmp_name"],"upload/".$dc_attachment);
		
		$invoice_attachment=$_FILES["invoice_attachment"]["name"];
        move_uploaded_file($_FILES["invoice_attachment"]["tmp_name"],"upload/".$invoice_attachment);
	   
	  if($mobilevalidation != 1){
		  echo'<script type="text/javascript">
                    jQuery(function validation(){
                    swal("Warning", "Enter valid mobile number", "warning", {
                    button: "Continue",
                        });
                    });
                    </script>';
	  }else{
	  $sql = "INSERT INTO vendor_details (vendor_name, mobile, company_name, id_proof, products, delivery_date, dc_no, dc_attachment ,invoice_number, invoice_attachment, receiver, department, deliver_person, quantity, vehical_number,vehical_type,in_time,id_type,id_number)
		VALUES ('$vendor_name', '$mobile', '$company_name', '$up_file', '$products', '$delivery_date', '$dc_no','$dc_attachment', '$invoice_number','$invoice_attachment', '$receiver' , '$department' , '$deliver_person' , '$quantity' , '$vehical_number', '$vehical_type','$in_time','$id_type','$id_number')";
			if (mysqli_query($conn, $sql)) {
				echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "New User Added", "success", {
                        button: "Continue",
                            });
                        });
                        </script>';
			} else {
				echo "Error: " . $sql . ":-" . mysqli_error($conn);
			}
	  }
	  
     mysqli_close($conn);
	  //echo '<script>location.href="order.php";</script>';

?>



