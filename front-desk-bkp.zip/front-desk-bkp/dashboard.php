<?php
    include_once'db/connect_db.php';
    session_start();
    if($_SESSION['role']=="Admin"){
      include_once'inc/header_all.php';
    }else{
        include_once'inc/header_all_operator.php';
    }
	error_reporting(0);
	

  
	
	   $id = $_GET['id'];
	 
	   $select = $pdo->prepare("SELECT user_type as type FROM  interview_candidates WHERE id=".$id);
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $usertype = $row->type;
		
		$select3 = $pdo->prepare("SELECT user_type as type2 FROM visitor_details WHERE s_no=".$id);
        $select3->execute();
        $row3=$select3->fetch(PDO::FETCH_OBJ);
        $usertype1 = $row3->type2;
		

		
		 $select2 = $pdo->prepare("SELECT user_type as type1 FROM vendor_details WHERE ve_id=".$id);
        $select2->execute();
        $row2=$select2->fetch(PDO::FETCH_OBJ);
        $usertype2 = $row2->type1;
		
		
	
		
		
	   
	  if(!isset($error)){
		  if($usertype == "candidate"){
			  $update = $pdo->prepare("UPDATE interview_candidates SET out_time=CURRENT_TIME() WHERE id=".$id);
				if($update->execute()){
					header('location:dashboard.php?id='.urlencode($id));
				} 
		  }
		  else if($usertype1 == "visistor"){
			  $update = $pdo->prepare("UPDATE visitor_details SET out_time=CURRENT_TIME() WHERE s_no=".$id);
				if($update->execute()){
					header('location:dashboard.php?id='.urlencode($id));
				} 
		  }
		   else if($usertype2 == "vendor"){
			  $update = $pdo->prepare("UPDATE vendor_details SET out_time=CURRENT_TIME() WHERE ve_id=".$id);
				if($update->execute()){
					header('location:dashboard.php?id='.urlencode($id));
				} 
		  }
		  
	  }
	   
	 
		  
	
?>
<style>
.p-0{
	padding:0 !important;
}
.mt-1{
	margin-top:10px !important;
}
.totall{
	margin: 0 ;
    margin-top: 10px;
    margin-bottom: 21px;
}
canvas.canvasjs-chart-canvas {
    border-top: 3px solid #f39c12;
}
.colorblue{
	padding: 2px 10px;
    background: #337ab7;
    color: white;
    font-size: 12px;
	width:80%;
}
.colorred{
	padding: 2px 13px;
    background: #f39c12;
    color: white;
    font-size: 12px;
}
.border-1{
	color: #f39c12;
	text-align: center;
    /* padding: 10px; */
    padding-bottom: 10px;
    font-size: 14px;
}
.border-2{
	color: #f39c12;
	text-align: center;
    padding: 10px; 
    padding-bottom: 10px;
    font-size: 14px;
}

</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content container-fluid">
  
<div class="row">
<div class="col-md-3">
        <!-- get alert stock -->
		
		 
		 <?php
		$select = $pdo->prepare("SELECT count(id) as total FROM  interview_candidates");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total1 = $row->total;
		
        $select2 = $pdo->prepare("SELECT count(ve_id) as total3 FROM vendor_details");
        $select2->execute();
        $row2=$select2->fetch(PDO::FETCH_OBJ);
        $total2 = $row2->total3;
		
		$select3 = $pdo->prepare("SELECT count(s_no) as total2 FROM visitor_details");
        $select3->execute();
        $row3=$select3->fetch(PDO::FETCH_OBJ);
        $total3 = $row3->total2;
 
$dataPoints = array( 
	array("label"=>"Candidates", "y"=>$total1),
	array("label"=>"Visitors", "y"=>$total3),
	array("label"=>"Vendors", "y"=> $total2),
	array("label"=>"Temporary Cards", "y"=> $total2)
	
)
 
?>
			 <h4 class="box-title totall">Total Data </h4>
 <div id="chartContainer" style="height: 240px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<?php
        $select = $pdo->prepare("SELECT count(id) as total FROM  interview_candidates where today_date >= CURDATE()");
		
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total1 = $row->total;
		
		
		$incandidates = $pdo->prepare("SELECT count(id) as total FROM  interview_candidates where out_time != 0 and today_date >= CURDATE();");
		$incandidates->execute();
        $row1=$incandidates->fetch(PDO::FETCH_OBJ);
        $total2 = $row1->total;
        ?>
		<br>
		<p>Today List</p>
		<div class="info-box">
 <div class="info-box-content1">
              <span class="info-box-text">Today Candidates</span>
              <?php if($total1==true){ ?>
              <span class="info-box-number"><small><?php echo $row->total;?></small></span>
			  <?php if($total2==true){ ?>
			   <span class="label label-warning pull-left">Out :  &nbsp; 
			 <?php echo $row1->total; ?> 
			   </span> 
			      <?php }?>
			   <span class="label label-success pull-right">In : &nbsp; 
			   <?php echo $total1 - $total2; ?>
			   
			   </span>
              <?php }else{?>
              <span class="info-box-text"><strong>0</strong></span>
              <?php }?>
            </div>
            <!-- /.info-box-content -->
          </div>
      
    	
        <!-- get today income -->
        <?php
        $select = $pdo->prepare("SELECT count(s_no) as total FROM visitor_details where visit_date >= CURDATE()");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total = $row->total ;
		
		$visitor_details = $pdo->prepare("SELECT count(s_no) as total1 FROM  visitor_details where out_time != 0 and visit_date >= CURDATE();");
		$visitor_details->execute();
        $row1=$visitor_details->fetch(PDO::FETCH_OBJ);
        $total2 = $row1->total1;
		
        ?>
		<div class="info-box">
            <div class="info-box-content1">
              <span class="info-box-text">Today Visitors</span>
			  
			   <?php if($total1==true){ ?>
              <span class="info-box-number"><small><?php echo $row->total;?></small></span>
			  <?php if($total2==true){ ?>
			   <span class="label label-warning pull-left"> Out : &nbsp; 
			 <?php echo $row1->total1; ?> 
			   </span> 
			      <?php }?>
			   <span class="label label-success pull-right">In : &nbsp; 
			   <?php echo $total - $total2; ?>
			   
			   </span>
              <?php }else{?>
              <span class="info-box-text"><strong>0</strong></span>
              <?php }?>
			  
			  
            </div>
            <!-- /.info-box-content -->
          </div>
         <!-- get today income -->
		 
		     <!-- get total products-->
        <?php
        $select = $pdo->prepare("SELECT count(ve_id) as t FROM vendor_details where today_date >= CURDATE()");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total = $row->t;
		
		
		$vendordetails = $pdo->prepare("SELECT count(ve_id) as total FROM  vendor_details where out_time != 0 and today_date >= CURDATE();");
		$vendordetails->execute();
        $row1=$vendordetails->fetch(PDO::FETCH_OBJ);
        $total2 = $row1->total;
        ?>  
		<div class="info-box">
      

            <div class="info-box-content1">
              <span class="info-box-text">Today Vendors</span>
                <?php if($total1==true){ ?>
              <span class="info-box-number"><small><?php echo $row->t;?></small></span>
			  <?php if($total2==true){ ?>
			   <span class="label label-warning pull-left"> Out : &nbsp; 
			 <?php echo $row1->total; ?> 
			   </span> 
			      <?php }?>
			   <span class="label label-success pull-right">In : &nbsp; 
			   <?php echo $total - $total2; ?>
			   
			   </span>
              <?php }else{?>
              <span class="info-box-text"><strong>0</strong></span>
              <?php }?>
            </div>
            <!-- /.info-box-content -->
          </div>
		 
		 
		
		 
		 <script>
window.onload = function() {
 
 
var chart = new CanvasJS.Chart("chartContainer", {
	theme: "light2",
	animationEnabled: true,
	
	data: [{
		type: "pie",
		indexLabel: "{y}",
		yValueFormatString: "#,##0\"\"",
		
		indexLabelFontColor: "#000",
		indexLabelFontSize: 18,
		indexLabelFontWeight: "bolder",
		showInLegend: true,
		legendText: "{label}",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
<style>
a.canvasjs-chart-credit {
    display: none;
}
</style>		 
		 
	 
		 
		 
        

	</div>
 
	  
	<div class="col-md-9">
		
		<div class="box-header with-border">
		  <h3 class="box-title mt-1">Today List </h3>
              <div class="col-md-3 pull-right p-0">
                  <div class="form-group" style="margin-bottom: -5px !important;">
                            <select class="form-control category1"  id="category1" name="category1">									
									<option value="candidate">Candidate</option>
									<option value="visitor">Visitor</option>
									<option value="vendor">Vendor</option>
                            </select>
                  </div>
				  </br>
                </div>
			  </br>
          </div>
		  
	  <div class="box box-success1" id="candidatesss">
          
          <div class="box-body">
		  <div class="box-header with-border border-1" style="margin-bottom:10px;"> 
		 <h3 class="box-title">Candidate List</h3>            
          </div>		 
            <div class="col-md-12">
              <div>
                 <table class="table table-striped" id="candidates">
                        <thead>
                            <tr>
                                <th style="width:20px;">Candidate ID</th>
								<th style="width:20px;">Candidate Name</th>
                                <th style="width:100px;">Mobile Number</th>
								<th style="width:20px;">Domain</th>
								<th style="width:20px;">Level Of Experience</th>
								<th style="width:20px;">Status</th>
								<th style="width:20px;">Print Card</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
							
                            $select = $pdo->prepare("SELECT * FROM interview_candidates where today_date >= CURDATE()");
                            $select->execute();
                            while($row=$select->fetch(PDO::FETCH_OBJ)){
                            ?>
                                <tr>
                                <td><?php echo $row->id; ?></td>
								<td><?php echo $row->candidate_name;?></td>
                                <td><?php echo $row->mobile; ?></td>
								<td><?php echo $row->technology; ?></td>
								<td><?php echo $row->category; ?></td>
								<td>
								<?php 
								if($row->in_time != 0 && $row->out_time <= 0 )
								{
									?>
									<a href="dashboard.php?id=<?php echo $row->id; ?>" 
									onclick="return confirm('Are You Sure Want To Out Time?')"
									><span class="colorblue" title="Please Click The Button To Logout">In Office</span> </a>
									
								<?php 
								}
								else
								{
								?>
								<span class="colorred" title="Candidate Already Out Of The Office">Logout </span>
								<?php } ?>
								</td>
								<td>
								<?php 
								if($row->in_time != 0 && $row->out_time <= 0 )
								{
									?>
									<a title="Click Here To Print" href="candidate-print.php?id=<?php echo $row->id; ?>" target="_blank" class="btn btn-info btn-sm"><i class="fa fa-print"></i></a>
									
								<?php 
								}
								else
								{
								?>
								 
								<?php } ?>
								</td>
								 
								
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
              </div>
            </div>
          </div>
        </div>
		
		
		<div class="box box-success1" id="vendorsss">
          <div class="box-header with-border border-2">
              <h3 class="box-title">Vendor List</h3>			 
          </div>
          <div class="box-body">
            <div class="col-md-12">
              <div>
                 <table class="table table-striped" id="vendor">
                        <thead>
                            <tr>
                                <th style="width:20px;">Vendor ID</th>
								<th style="width:20px;">Vendor Name</th>
                                <th style="width:100px;">Mobile</th>
								<th style="width:100px;">Company Name</th>								
								<th style="width:50px;">Receiver</th>
								<th style="width:20px;">Status</th>
								<th style="width:20px;">Print Card</th>
								
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
							
                            $select = $pdo->prepare("SELECT * FROM vendor_details where today_date >= CURDATE()");
                            $select->execute();
                            while($row=$select->fetch(PDO::FETCH_OBJ)){
                            ?>
                                <tr>
                                <td><?php echo $row->ve_id; ?></td>
								<td class="text-uppercase"><?php echo $row->vendor_name; ?></td>
                                <td><?php echo $row->mobile; ?></td>
								 <td><?php echo $row->company_name; ?></td>
								 <td><?php echo $row->receiver; ?></td>
								<td>
								<?php 
								if($row->in_time != 0 && $row->out_time <= 0 )
								{
									?>
									<a href="dashboard.php?id=<?php echo $row->ve_id; ?>" 
									onclick="return confirm('Are You Sure Want To Out Time?')"
									><span class="colorblue" title="Please Click The Button To Logout">In Office</span> </a>
									
								<?php 
								}
								else
								{
								?>
								<span class="colorred" title="Candidate Already Out Of The Office">Logout </span>
								<?php } ?>
								</td>
								
								
									<td>
								<?php 
								if($row->in_time != 0 && $row->out_time <= 0 )
								{
									?>
									<a title="Click Here To Print" href="vendor-print.php?id=<?php echo $row->ve_id; ?>" target="_blank" class="btn btn-info btn-sm"><i class="fa fa-print"></i></a>
									
								<?php 
								}
								else
								{
								?>
							
								<?php } ?>
								</td>
								
								
								
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
              </div>
            </div>
          </div>
        </div>
		
		
		<div class="box box-success1" id="visitorsss">
          <div class="box-header with-border border-2">
              <h3 class="box-title">Visitor List</h3>			
          </div>
          <div class="box-body">
            <div class="col-md-12">
              <div>
                 <table class="table table-striped" id="visitor">
                        <thead>
                            <tr>
                                <th style="width:20px;">Visitor ID</th>
								<th style="width:20px;">Name</th>
                                <th style="width:100px;">Mobile</th>
								<th style="width:100px;">Purpose of Visit</th>
								 <th style="width:100px;">Whom to meet</th>
									<th style="width:20px;">Status</th>
									<th style="width:20px;">Print Card</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
							
                            $select = $pdo->prepare("SELECT * FROM visitor_details where visit_date >= CURDATE()");
                            $select->execute();
                            while($row=$select->fetch(PDO::FETCH_OBJ)){
                            ?>
                                <tr>
                                <td><?php echo $row->s_no; ?></td>
								<td class="text-uppercase"><?php echo $row->visitor_name; ?></td>
                                <td><?php echo $row->mobile; ?></td>
								 <td><?php echo $row->purpose; ?></td>
								 <td><?php echo $row->meeting_person; ?></td>
								<td>
								<?php 
								if($row->in_time != 0 && $row->out_time <= 0 )
								{
									?>
									<a href="dashboard.php?id=<?php echo $row->s_no; ?>" 
									onclick="return confirm('Are You Sure Want To Out Time?')"
									><span class="colorblue" title="Please Click The Button To Logout">In Office</span> </a>
									
								<?php 
								}
								else
								{
								?>
								<span class="colorred" title="Candidate Already Out Of The Office">Logout </span>
								<?php } ?>
								</td>
								
								<td>
								<?php 
								if($row->in_time != 0 && $row->out_time <= 0 )
								{
									?>
									<a title="Click Here To Print" href="visitor-print.php?id=<?php echo $row->s_no; ?>" target="_blank" class="btn btn-info btn-sm"><i class="fa fa-print"></i></a>
									
								<?php 
								}
								else
								{
								?>
								
								<?php } ?>
								</td>
								
								
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
              </div>
            </div>
          </div>
        </div>
		
		
		
		
		
	</div>
	
	
	  </div>
    </section>
    <!-- /.content -->
  </div>
  
  <!-- /.content-wrapper -->
  <script>
  $(document).ready( function () {
      $('#myBestProduct').DataTable();
  } );
  </script>
  
  <style>
  .info-box-content1 {
    text-align: center;
    padding: 20px;
}
.info-box {
    border-left: 5px solid #f39c12;
}
th input {
    padding: 6px;
    font-weight: 500;
    font-size: 12px;
}

th:nth-child(1) input{  
	display:none !important;
}
th input{
	padding:6px;
	font-weight:500;
	font-size:12px;
}


  </style>
  
  
    <script>
  $(document).ready( function () {

 
$('#candidates').DataTable();
$('#vendor').DataTable();
$('#visitor').DataTable();
 
} );
	
 
  </script>
  
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
 <script>
  $(document).ready(function() {
  	$("#candidatesss").show();
	$("#vendorsss").hide();
	$("#visitorsss").hide();
			const selectElement = document.querySelector('.category1');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "candidate"){
				$("#candidatesss").show();
				$("#vendorsss").hide();
				$("#visitorsss").hide();
			}
			else if(category == "visitor"){
				$("#visitorsss").show();
				$("#candidatesss").hide();
				$("#vendorsss").hide();
			}
			
			else if(category == "vendor"){
				$("#candidatesss").hide();
				$("#visitorsss").hide();
				$("#vendorsss").show();
			}
			else{
				$("#candidatesss").hide();
				$("#visitorsss").hide();
				$("#vendorsss").hide();
			}
						
});
  });
	
 
  </script>
  
  
  
  
  
  
  


 <?php
    include_once'inc/footer_all.php';
 ?>