<?php
    include_once'db/connect_db.php';
	
	?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet">	
<style>
 
body {font-family: 'Poppins', sans-serif; font-size: 12px}
body {
        height: 80mm;
        width: 50mm;
		border:solid 1px #2f405417;    border-radius: 10px;
    }
dt { float: left; clear: left; text-align: right; font-weight: bold; margin-right: 10px } 
dd {  padding: 0 0 0.5em 0; }
.person-logo{
	margin-left: 26px;
    width: 130px;
    height: 130px;
    margin-top: 5px;
	margin-bottom: 5px;

}
.respo{
	text-align:right;
	width:50%;
}
.ojas-logo{
	height:50px;
	margin-left:35px; margin-top:5px;
}
table tr{
	line-height:13px;
}table td{
	color:#efaf4e;
}
</style> 
<style type="text/css" media="print">
@page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */
    }
</style>   
</head>

<body> 



<table cellspacing='3' cellpadding='3' WIDTH='100%'>
<?php
                            $no = 1;
							$id = $_GET['id'];
                            $select = $pdo->prepare("SELECT * FROM interview_candidates WHERE id=".$id);
                            $select->execute();
                            while($row=$select->fetch(PDO::FETCH_OBJ)){
                            ?>
<img src="ojas-logo.png" alt="" class="ojas-logo">
<img src="user.jpg" alt="" class="logo person-logo" >
<!--<?php echo $row->emp_image?>-->
<tr>
<td class="respo" valign='top'><strong>Name :</strong></td>
<td valign='top'><strong><?php echo $row->candidate_name; ?></strong></td> 
</tr>
<tr>
<td class="respo" valign='top'><strong>ID No :</strong></td>
<td valign='top'><strong><?php echo $row->id; ?></strong></td> 
</tr>
<tr>
<td class="respo" valign='top'><strong>Domain :</strong></td> 
<td valign='top'><strong><?php echo $row->technology; ?></strong></td>
</tr>
<tr>
<td class="respo" valign='top'><strong>Purpose :</strong></td> 
<td valign='top'><strong>Interview</strong></td>
</tr>
<?php
}
?>
</table>
 
</body>
</html> 