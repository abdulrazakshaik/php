<?php
  include_once'db/connect_db.php';
  session_start();
  if($_SESSION['role']!=="Admin"){
    header('location:index.php');
  }
  include_once'inc/header_all.php';

  if(isset($_POST['submit'])){

    $employee_id = $_POST['employee_id'];
    $employee_name = $_POST['employee_name'];
    $employee_email = $_POST['employee_email'];
    $employee_mobile= $_POST['employee_mobile'];
    $employee_manager = $_POST['employee_manager'];
    $manager_email = $_POST['manager_email'];
    $purpose = $_POST['purpose'];
    $card = $_POST['card'];
    $it_person = $_POST['it_person'];
  		
            $insert = $pdo->prepare("INSERT INTO employee_idcards(employee_id,employee_name,employee_email,employee_mobile,employee_manager,manager_email,card,it_person,purpose) VALUES ('$employee_id','$employee_name','$employee_email','$employee_mobile','$employee_manager','$manager_email','$card','$it_person','$purpose')");

            if($insert->execute()){
              echo '<script type="text/javascript">
              jQuery(function validation(){
              swal("Success", "Employee Details", "success", {
              button: "Continue",
                  });
              });
              </script>';
            }
			else{
              echo '<script type="text/javascript">
              jQuery(function validation(){
              swal("warning", "you can try again", "warning", {
              button: "Continue",
                  });
              });
              </script>';
            }
     
  }
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
  
    <!-- Main content -->
    <section class="content container-fluid">
       <!-- Category Form-->
      <div class="col-md-12" style="margin-bottom:50px;">
            <div class="box box-success">
                <!-- /.box-header -->
                <!-- form start -->
                <form action="" method="POST">
                  <div class="box-body">
                    <div class="form-group col-md-4">
                      <label for="category">Employee Id</label>
                      <input type="text" class="form-control" name="employee_id" >
                    </div>
					<div class="form-group col-md-4">
                      <label for="category">Employee Name</label>
                      <input type="text" class="form-control" name="employee_name" >
                    </div>
					<div class="form-group col-md-4">
                      <label for="category">Employee Email</label>
                      <input type="text" class="form-control" name="employee_email" >
                    </div>
					<div class="form-group col-md-4">
                      <label for="category">Employee Mobile</label>
                      <input type="text" class="form-control" name="employee_mobile" >
                    </div>										
					<div class="form-group col-md-4">
                      <label for="category">Manager Name</label>
                      <input type="text" class="form-control" name="employee_manager" >
                    </div>
					<div class="form-group col-md-4">
                      <label for="category">Manager Email</label>
                      <input type="text" class="form-control" name="manager_email" >
                    </div>
					<div class="form-group col-md-4">
                     <label for="">Select Purpose <span class="warning-color">*</span></label>
                      <select class="form-control" name="purpose" required >
									<option >Enter option</option>
									<option>Forgot ID Card</option>
									<option>Lost ID Card</option>                               
                            </select>
                        </div>
					<div class="form-group col-md-4">
                      <label for="category">ID Card Number</label>
                      <input type="text" class="form-control" name="card">
                    </div>
					<div class="form-group col-md-4">
                      <label for="category">Assigned By</label>
                      <input type="text" class="form-control" name="it_person" >
                    </div>
					
                  </div><!-- /.box-body -->
                  <div class="box-footer">
                      <button type="submit" class="btn btn-primary pull-right" name="submit">Assign Card</button>
                   </div>
                </form>
            </div>
      </div>
	  
        <!-- Category Table -->
      <div class="col-md-12">
        <div class="box">
          <div class="box-header with-border">
            <h3 class="box-title list-h">Employee Cards List</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body" style="overflow-x:auto;">
            <table class="table table-striped" id="myCategory">
                <thead>
                    <tr>                         
                        <th>Emp Id</th>
						<th>Name</th>
						<th>Email</th>
						<th>Mobile</th>
                        <th>Manager</th>
						<th>Manager Email</th>
						<th>Purpose</th>
						<th>Card Number</th>
                        <th>Assigned by</th>
                        <th>Options</th>
                    </tr>

                </thead>
                <tbody>
               <?php
                $select = $pdo->prepare(' SELECT * from employee_idcards');
                $select->execute();
                while($row=$select->fetch(PDO::FETCH_OBJ)){					 
					?>
                  <tr>
                    <td><?php echo $row->employee_id; ?></td>
                    <td><?php echo $row->employee_name; ?></td>
                    <td><?php echo $row->employee_email; ?></td>
                    <td><?php echo $row->employee_mobile; ?></td>
                    <td><?php echo $row->employee_manager; ?></td>
                    <td><?php echo $row->manager_email; ?></td>
                    <td><?php echo $row->purpose; ?></td>
                    <td><?php echo $row->card; ?></td>
                    <td><?php echo $row->it_person; ?></td>
                   
                    <td>
                        <a href="edit_category.php?id=<?php echo $row->id; ?>"
                        class="btn btn-info btn-sm" name="btn_edit"><i class="fa fa-pencil"></i></a>
						
                        <!--<a href="delete_category.php?id=<?php echo $row->id; ?>"
                        onclick="return confirm('Delete Category?')"
                        class="btn btn-danger btn-sm" name="btn_delete"><i class="fa fa-trash"></i></a>-->
                    </td>
                  </tr>
                <?php
                }
                ?>

                </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>


    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- DataTables Function -->
  <script>
  $(document).ready( function () {
      $('#myCategory').DataTable();
  } );
  </script>

<?php
  include_once'inc/footer_all.php';
?>