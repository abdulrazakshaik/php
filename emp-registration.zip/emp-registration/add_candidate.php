<?php

 $servername='localhost';
    $username='root';
    $password='';
    $dbname = "employee_registration";
    $conn=mysqli_connect($servername,$username,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
		
		
		
    session_start();
   if($_SESSION['username']==""){
     include_once'inc/404.php';
   }else{
     if($_SESSION['role']=="Admin"){
       include_once'inc/header_all.php';
     }else{
         include_once'inc/header_all_operator.php';
     }
   }

 
if(isset($_POST['save_candidate'])){ 
   
     $candidate_name = $_POST['candidate_name'];
      $mobile = $_POST['mobile'];	 
      $technology = $_POST['technology'];
	 $email = $_POST['email'];
	 $category = $_POST['category'];
	 $location = $_POST['location'];
	 $id_number = $_POST['id_number'];
	 $experience = $_POST['experience'];
	 	
	  $in_time = $_POST['in_time'];
	 $out_time = $_POST['out_time'];
	  $schdule_name = $_POST['schdule_name'];
	  
	    $up_file=$_FILES["id_proof"]["name"];
        move_uploaded_file($_FILES["id_proof"]["tmp_name"],"upload/".$up_file);
	  
     $sql = "INSERT INTO interview_candidates (candidate_name, email,mobile, technology,category,location, id_proof,id_number, in_time,out_time, schdule_name,experience)
     VALUES ('$candidate_name','$email','$mobile','$technology','$category','$location','$up_file','$id_number','$in_time','$out_time','$schdule_name','$experience')";
 
     if (mysqli_query($conn, $sql)) {
        echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "New User Added", "success", {
                        button: "Continue",
                            });
                        });
                        </script>';
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
	  //echo '<script>location.href="order.php";</script>';
}
 
	
	
	 

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
		<section class="content-header">
		  <h1>
			Candidate Info
		  </h1>
		  
		</section>

    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
          <form action="" method="POST" enctype="multipart/form-data">
           
			<div class="box-body">
			
              <div class="col-md-12">
			  <h4>Candidate Details</h4>
			  <br>
			   <div class="form-group col-md-3">
                  <label>Candidate Name</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Name</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="candidate_name" id="candidate_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Email</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>email</span>
                    </div>
                    <input type="email" class="form-control pull-right" name="email" id="email" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				
				
                <div class="form-group col-md-3">
                  <label>Mobile Number</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Name</span>
                    </div>
                    <input type="number" class="form-control pull-right" name="mobile" id="mobile" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
                <div class="form-group col-md-3">
                  <label>Technology</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Technology</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="technology" id="technology" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				<!--<div class="form-group col-md-3">
                  <label>ID Proof</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>proof</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="id_proof" id="id_proof" required>
                  </div>
                  
                </div>-->
				
				
               
              </div>
            </div>
			
            <div class="box-body">
              <div class="col-md-12">
				
				
				
				 <div class="col-md-3 form-group">
                            <label for="">ID Proof</label><br>
               
                            <input type="file" class="input-group" id="id_proof"
                            name="id_proof" > <br>
                      
						  <!-- /.input group -->
                    </div>
					
				<div class="form-group col-md-3">
					<label>ID Number</label>
						<div class="input-group">
							<div class="input-group-addon">
								<span>ID.Num</span>
							</div>
							<input type="text" class="form-control pull-right" name="id_number" id="id_number" required>
						</div>
                  <!-- /.input group -->
                </div>
					
				
					
				<div class="form-group col-md-3">
                  <label>Location</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Location</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="location" id="location" required >
                  </div>
                  <!-- /.input group -->
                </div>

	
				 <div class="form-group col-md-3">
                  <label>Scheduled Name</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Scheduled Name</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="schdule_name" id="schdule_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
			 

              </div>
            </div>  

				<div class="box-body">
              <div class="col-md-12">

				
				<div class="form-group col-md-3">
                  <label>In Time</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>time</span>
                    </div>
                    <input type="time" class="form-control pull-right" name="in_time" id="in_time" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Out Time</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>time</span>
                    </div>
                    <input type="time" class="form-control pull-right" name="out_time" id="out_time" required >
                  </div>
                  <!-- /.input group -->
                </div>
	
			  
				
				 <div class="form-group col-md-3">
                            <label for="">Category</label>
                            <select class="form-control category"  id="category" name="category" required>
									<option >Enter option</option>
									<option>Fresher</option>
									<option>Experience</option>
                               
                            </select>
                        </div>
						
				<div class="form-group col-md-3" id="experience">
                  <label>Experience</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>experience</span>
                    </div>
                    <input type="text" class="form-control pull-right" value="0" name="experience" id="experience" required >
                  </div>
                  <!-- /.input group -->
                </div>		
				

              </div>
            </div> 
			
			<br><br>
			
            <div class="box-footer" align="center">
              <input type="submit" name="save_candidate" value="Save Candidate" class="btn btn-success">
              <a href="candidates.php" class="btn btn-warning">Back</a>
            </div>
          </form>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  

  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){ 
			$("#experience").hide();
			const selectElement = document.querySelector('.category');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "Experience"){
				$("#experience").show();
			}
			else{
				$("#experience").hide();
			}
			
});
    });
  </script>

  <script>
  //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  
  </script>

  
  


 <?php
    include_once'inc/footer_all.php';
 ?>