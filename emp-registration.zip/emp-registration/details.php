<?php
   $servername='localhost';
    $username='root';
    $password='';
    $dbname = "employee_registration";
    $conn=mysqli_connect($servername,$username,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
	session_start();
   if($_SESSION['username']==""){
     include_once'inc/404.php';
   }else{
     if($_SESSION['role']=="Admin"){
       include_once'inc/header_all.php';
     }else{
         include_once'inc/header_all_operator.php';
     }
   }
   
   if(isset($_POST['save_candidate'])){ 
	include_once 'db/insertCandidates.php';
   }
   
   if(isset($_POST['save_visitor'])){ 
	include_once 'db/insertVisitors.php';
   }
   
    if(isset($_POST['save_vendor'])){ 
	include_once 'db/insertVendor.php';
   }
   
?>

<html>
<head>
<meta http-equiv="refresh" content="60">

<style>
th:nth-child(1) input,th:last-child input{  
	display:none !important;
}
th input{
	padding:6px;
	font-weight:500;
	font-size:12px;
}

</style>


 
</head>
</html>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) 
    <section class="content-header">
      <h1>
        Candidates
      </h1>
      <hr>
    </section>-->

    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
            <div class="box-header with-border">
			<div class="box-body">
               <section>	
						<div class="form-group col-md-3">
						<label for="" class="padding-all">Purpose of Visit</label>
               <select class="form-control detailss" id="detailss" name="detailss">
					
					<option value="interview">Interview</option>
					<option value="visitor">Visitor</option>
					<option value="vendor">Vendor</option>
                               
                            </select>	
					</div>
				</section>
				</div>
            </div>
            <div class="box-body">
				 <section class="">	
        <div class="box box-success border-none" id="interview">
          <form action="" method="POST" enctype="multipart/form-data">		  
			<div class="box-body">			
			  <h4 class="list-head">Candidate Details</h4>
			  <br>
			   <div class="form-group col-md-3">
                  <label>Candidate Name</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="candidate_name" id="candidate_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Email</label>
                  <div class="">
                    
                    <input type="email" class="form-control pull-right" name="email" id="email" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				
				
                <div class="form-group col-md-3">
                  <label>Mobile Number</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="mobile" id="mobile" required max="10">
                  </div>
                  <!-- /.input group -->
                </div>
				
                <div class="form-group col-md-3">
                  <label>Technology</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="technology" id="technology" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				<!--<div class="form-group col-md-3">
                  <label>ID Proof</label>
                  <div class="">
                    <div class="-addon">
                      <span>proof</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="id_proof" id="id_proof" required>
                  </div>
                  
                </div>-->
				
				
              
            </div>
			
            <div class="box-body">
          
				
				
				
				 <div class="col-md-3 form-group">
                            <label for="">ID Proof</label><br>
               
                            <input type="file" class="" id="id_proof"
                            name="id_proof" > <br>
                      
						  <!-- /.input group -->
                    </div>
					
				<div class="form-group col-md-3">
					<label>ID Proof Number</label>
						<div class="">
							
							<input type="text" class="form-control pull-right" name="id_number" id="id_number" required>
						</div>
                  <!-- /.input group -->
                </div>
					
				
					
				<div class="form-group col-md-3">
                  <label>Location</label>
                  <div class="">
                   
                    <input type="text" class="form-control pull-right" name="location" id="location" required >
                  </div>
                  <!-- /.input group -->
                </div>

	
				 <div class="form-group col-md-3">
                  <label>Scheduled Name</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="schdule_name" id="schdule_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
			 

              </div>
         

				<div class="box-body">           

				
				<div class="form-group col-md-3">
                  <label>In Time</label>
                  <div class="">
                    
                    <input type="time" class="form-control pull-right" name="in_time" id="in_time" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Out Time</label>
                  <div class="">
                    
                    <input type="time" class="form-control pull-right" name="out_time" id="out_time" value="0">
                  </div>
                  <!-- /.input group -->
                </div>	
			  
				
				 <div class="form-group col-md-3">
                            <label for="">Experience</label>
                            <select class="form-control category"  id="category" name="category" required>
									<option >Enter option</option>
									<option>Fresher</option>
									<option>Experience</option>
                               
                            </select>
                        </div>
						
				<div class="form-group col-md-3" id="experience">
                  <label>Year's of Experience</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" value="0" name="experience" id="experience" required >
                  </div>
                  <!-- /.input group -->
                </div>	


				 <div class="form-group col-md-3">
                            <label for="">Type of Vehical</label>
                            <select class="form-control typevehical"  id="vehical" name="vehical" required>
									<option value="0">Enter option</option>
									<option value="2">Two</option>
									<option value="4">Four</option>
									<option value="10">No Vehical</option>
                               
                            </select>
                        </div>
						
				<div class="form-group col-md-3" id="vehical_number">
                  <label>Vehical Number</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" value="0" name="vehical_number" id="vehical_number" required >
                  </div>
                  <!-- /.input group -->
                </div>	
				

            
            </div> 
			
			<br><br>
			
            <div class="box-footer" align="center">
              <input type="submit" name="save_candidate" value="Save Candidate" class="btn btn-success">
              <a href="candidates.php" class="btn btn-warning">Back</a>
            </div>
          </form>
		  
        </div>
		
		
		
		<div class="box box-success border-none" id="visitor">
          <form action="" method="POST" enctype="multipart/form-data" >
           
			<div class="box-body">
			
             
			  <h4 class="list-head">Visitor Details</h4>
			  <br>
			   <div class="form-group col-md-3">
                  <label>Visitor Name</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="visitor_name" id="visitor_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Mobile Number</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="mobile" id="mobile" required max="10">
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Purpose of Visit</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="purpose" id="purpose" required>
                  </div>
                  <!-- /.input group -->
                </div>
				  <!--<div class="form-group col-md-3">
                  <label>ID Proof</label>
                  <div class="">
                    <div class="-addon">
                      <span>proof</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="id_proof" id="id_proof" required>
                  </div>
                </div>-->              
			   
			    <div class="col-md-3">
                        <div class="form-group">
                            <label for="">ID Proof</label><br>
                            
                            <input type="file" class="" id="id_proof"
                            name="id_proof"> <br>
                        </div>
						  <!-- /.input group -->
                    </div>
					
					
              </div>
             
            <div class="box-body">
              
			  
			<div class="form-group col-md-3">
                  <label>Id Number</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="visitor_id" id="visitor_id" required >
                  </div>
                  <!-- /.input group -->
                </div>


				<div class="form-group col-md-3">
                  <label>Whom to meet</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="meeting_person" id="meeting_person" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>In Time</label>
                  <div class="">
                   
                    <input type="time" class="form-control pull-right" name="in_time" id="in_time" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Out Time</label>
                  <div class="">
                    
                    <input type="time" class="form-control pull-right" name="out_time" id="out_time" required >
                  </div>
                  <!-- /.input group -->
                </div>
				</div>
				 <div class="box-body">
			  
			  
			   <div class="form-group col-md-3">
                            <label for="">Type of Vehical</label>
                            <select class="form-control visitorVehical"  id="vehical_type" name="vehical_type" required>
									<option value="0">Enter option</option>
									<option value="2">Two</option>
									<option value="4">Four</option>
									<option value="10">No Vehical</option>
                               
                            </select>
                        </div>
						
						
						
				 <div class="form-group col-md-3" id="visitorVehical">
                  <label>vehical Number</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" value = "0" name="vehical_number" id="vehical_number" required style="text-transform:uppercase">
                  </div>
                  <!-- /.input group -->
                
				
	
              </div>
            </div>     
			<br><br>
			
            <div class="box-footer" align="center">
              <input type="submit" name="save_visitor" value="Save Candidate" class="btn btn-success">
              <a href="visitor.php" class="btn btn-warning">Back</a>
            </div>
          </form>
        </div>
		
		
		
		<div class="box box-success border-none" id="vendor">
          <form action="" method="POST" enctype="multipart/form-data">
		  <div class="box-body">
			 
			  <h4  class="list-head">Vendor Info</h4>
			  <br>
			   <div class="form-group col-md-3">
                  <label>Vendor Name</label>
                  <div class="">
                    <input type="text" class="form-control pull-right" name="vendor_name" id="vendor_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Mobile</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="mobile" id="mobile" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Company Name</label>
                  <div class="">
                   
                    <input type="text" class="form-control pull-right" name="company_name" id="company_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
			
				
				 <div class="col-md-3">
                        <div class="form-group">
                            <label for="">ID Proof</label><br>
                            
                            <input type="file" class="" id="id_proof"
                            name="id_proof" > <br>
                        </div>
						  <!-- /.input group -->
                    </div>
               
              </div>
            
            <div class="box-body">
            

			<div class="form-group col-md-3">
                  <label>Products</label>
                  <div class="">
                   
                    <input type="text" class="form-control pull-right" name="products" id="products" required>
                  </div>
                  <!-- /.input group -->
                </div>
				

	
			   <div class="form-group col-md-3">
                  <label>Delivery Date</label>
                  <div class="">
                    
                    <input type="date" class="form-control pull-right" name="delivery_date" id="delivery_date" required>
                  </div>
                  <!-- /.input group -->
                </div>

				<div class="form-group col-md-3">
                  <label>DC no</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="dc_no" id="dc_no" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				 <div class="col-md-3 form-group">
                            <label for="">DC Attachment</label><br>
                            
                            <input type="file" class="" id="dc_attachment"
                            name="dc_attachment"> <br>
                        
						  <!-- /.input group -->
                 </div>				
             </div>
           
			 <div class="box-body">
              	
			  
			   <div class="form-group col-md-3">
                  <label>Invoice Number</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="invoice_number" id="invoice_number" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="col-md-3 form-group">
                            <label for="">Invoice Attachment</label><br>
                            
                            <input type="file" class="" id="invoice_attachment"
                            name="invoice_attachment"> <br>
                        
						  <!-- /.input group -->
                 </div>	
				<div class="form-group col-md-3">
                  <label>Receiver</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" name="receiver" id="receiver" required>
                  </div>
                  <!-- /.input group -->
                </div> 
				<div class="form-group col-md-3">
                  <label>Department</label>
                  <div class="">
                    <input type="text"  class="form-control pull-right" name="department" id="department" required>
                  </div>
                  <!-- /.input group -->
                </div>		
					</div>
					 
				<div class="box-body">
             	
			  <div class="form-group col-md-3">
                  <label>Whom to Deliver</label>
                  <div class="">
                    <input type="text" class="form-control pull-right" name="deliver_person" id="deliver_person" required>
                  </div>
                  <!-- /.input group -->
                </div>
				<div class="form-group col-md-3">
                  <label>Quantity</label>
                  <div class="">
                    
                    <input type="number" class="form-control pull-right" name="quantity" id="quantity" required>
                  </div>
                  <!-- /.input group -->
                </div>
				 <div class="form-group col-md-3">
                            <label for="">Type of Vehical</label>
                            <select class="form-control vendorVehical"  id="vehical_type" name="vehical_type" required>
									<option value="0">Enter option</option>
									<option value="2">Two</option>
									<option value="4">Four</option>
									<option value="10">No Vehical</option>
                               
                            </select>
                        </div>
				  <div class="form-group col-md-3" id="vendorVehical">
                  <label>vehical Number</label>
                  <div class="">
                    
                    <input type="text" class="form-control pull-right" value="0" name="vehical_number" id="vehical_number" required style="text-transform:uppercase">
                  </div>
                  <!-- /.input group -->
                </div>
 
            </div>				
			<br><br>
			  <div class="box-footer" align="center">
              <input type="submit" name="save_vendor" value="Save vendor" class="btn btn-success">
              <a href="vendor.php" class="btn btn-warning">Back</a>
            </div>
          </form>
          
        </div>
	</section>
            </div>

        </div>


    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
 <script>
  $(document).ready(function() {
  	$("#interview").show();
	$("#visitor").hide();
	$("#vendor").hide();
			const selectElement = document.querySelector('.detailss');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "interview"){
				$("#interview").show();
				$("#visitor").hide();
			}
			else if(category == "visitor"){
				$("#visitor").show();
				$("#interview").hide();
				$("#vendor").hide();
			}
			
			else if(category == "vendor"){
				$("#interview").hide();
				$("#visitor").hide();
				$("#vendor").show();
			}
			else{
				$("#interview").hide();
				$("#visitor").hide();
				$("#vendor").hide();
			}
						
});
  });
	
 
  </script>
  
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){ 
			$("#experience").hide();
			const selectElement = document.querySelector('.category');
			selectElement.addEventListener('change', (event) => {
			var category = event.target.value;
			if(category == "Experience"){
				$("#experience").show();
			}
			
			else{
				$("#experience").hide();
			}
			
		
});
    });
  </script>
  
   <script type="text/javascript">
    $(document).ready(function(){ 
			$("#vendorVehical").hide();
			const selectElement = document.querySelector('.vendorVehical');
			selectElement.addEventListener('change', (event) => {
			var valueee = event.target.value;
			if(valueee == "2" || valueee == "4"){
				$("#vendorVehical").show();
			}
			else if(valueee == "10"){
				$("#vendorVehical").hide();
			}
			
			else{
				$("#vendorVehical").hide();
			}
			
		
});
    });
  </script>
  
  <script type="text/javascript">
    $(document).ready(function(){ 
			$("#visitorVehical").hide();
			const selectElement = document.querySelector('.visitorVehical');
			selectElement.addEventListener('change', (event) => {
			var valueee = event.target.value;
			if(valueee == "2" || valueee == "4"){
				$("#visitorVehical").show();
			}
			else if(valueee == "10"){
				$("#visitorVehical").hide();
			}
			
			else{
				$("#visitorVehical").hide();
			}
			
		
});
    });
  </script>
  
  
   <script type="text/javascript">
    $(document).ready(function(){ 
			$("#vehical_number").hide();
			const selectElement = document.querySelector('.typevehical');
			selectElement.addEventListener('change', (event) => {
			var valueee = event.target.value;
			if(valueee == "2" || valueee == "4"){
				$("#vehical_number").show();
			}
			else if(valueee == "10"){
				$("#vehical_number").hide();
			}
			
			else{
				$("#vehical_number").hide();
			}
			
		
});
    });
  </script>

  <script>
  //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  
  </script>
  
   
 <?php
    include_once'inc/footer_all.php';
 ?>