<?php

 $servername='localhost';
    $username='root';
    $password='';
    $dbname = "employee_registration";
    $conn=mysqli_connect($servername,$username,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
		
		
		
    session_start();
   if($_SESSION['username']==""){
     include_once'inc/404.php';
   }else{
     if($_SESSION['role']=="Admin"){
       include_once'inc/header_all.php';
     }else{
         include_once'inc/header_all_operator.php';
     }
   }

 
if(isset($_POST['save_visitor'])){    
     $visitor_name = $_POST['visitor_name'];
      $mobile = $_POST['mobile'];	 
      $purpose = $_POST['purpose']; 
      $in_time = $_POST['in_time']; 
      $out_time = $_POST['out_time']; 
      $vehical_number = $_POST['vehical_number'];
	  
	  $meeting_person = $_POST['meeting_person'];
	  
	  $up_file=$_FILES["id_proof"]["name"];
        move_uploaded_file($_FILES["id_proof"]["tmp_name"],"upload/".$up_file);
	  
     $sql = "INSERT INTO visitor_details (visitor_name, mobile, purpose, id_proof, meeting_person,in_time,out_time,vehical_number)
     VALUES ('$visitor_name','$mobile','$purpose','$up_file','$meeting_person','$in_time','$out_time','$vehical_number' )";
 
     if (mysqli_query($conn, $sql)) {
        echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "New User Added", "success", {
                        button: "Continue",
                            });
                        });
                        </script>';
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
	 

	
     mysqli_close($conn);
	  //echo '<script>location.href="order.php";</script>';
}
 
	
	
	 

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Visitors Info
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
          <form action="" method="POST" enctype="multipart/form-data" >
           
			<div class="box-body">
			
              <div class="col-md-12">
			  <h4>Visitor Details</h4>
			  <br>
			   <div class="form-group col-md-3">
                  <label>Visitor Name</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Name</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="visitor_name" id="visitor_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Mobile Number</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Name</span>
                    </div>
                    <input type="number" class="form-control pull-right" name="mobile" id="mobile" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Purpose of Visit</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Purpose</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="purpose" id="purpose" required>
                  </div>
                  <!-- /.input group -->
                </div>
				  <!--<div class="form-group col-md-3">
                  <label>ID Proof</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>proof</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="id_proof" id="id_proof" required>
                  </div>
                </div>-->
               
			   
			    <div class="col-md-3">
                        <div class="form-group">
                            <label for="">ID Proof</label><br>
                            
                            <input type="file" class="input-group" id="id_proof"
                            name="id_proof"> <br>
                        </div>
						  <!-- /.input group -->
                    </div>
					
					
              </div>
            </div>
            <div class="box-body">
              <div class="col-md-12">


				<div class="form-group col-md-3">
                  <label>Whom to meet</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>meet</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="meeting_person" id="meeting_person" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>In Time</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>time</span>
                    </div>
                    <input type="time" class="form-control pull-right" name="in_time" id="in_time" required >
                  </div>
                  <!-- /.input group -->
                </div>
				
				<div class="form-group col-md-3">
                  <label>Out Time</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>time</span>
                    </div>
                    <input type="time" class="form-control pull-right" name="out_time" id="out_time" required >
                  </div>
                  <!-- /.input group -->
                </div>
	
			  
				 <div class="form-group col-md-3">
                  <label>vehical Number</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Vehicle</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="vehical_number" id="vehical_number" required style="text-transform:uppercase">
                  </div>
                  <!-- /.input group -->
                </div>
				
				
				
              </div>
            </div>     
			<br><br>
			
            <div class="box-footer" align="center">
              <input type="submit" name="save_visitor" value="Save Candidate" class="btn btn-success">
              <a href="visitor.php" class="btn btn-warning">Back</a>
            </div>
          </form>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  



  <script>
  //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  
  </script>


 <?php
    include_once'inc/footer_all.php';
 ?>