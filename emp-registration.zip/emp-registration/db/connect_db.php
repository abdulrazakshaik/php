<?php

try{
    $pdo = new PDO('mysql:host=localhost;dbname=employee_registration','root','');
    //echo 'Connection Successfull';
}catch(PDOException $error){
    echo $error->getmessage();
}


?>