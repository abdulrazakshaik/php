<?php


     $visitor_name = $_POST['visitor_name'];
      $mobile = $_POST['mobile'];	 
      $purpose = $_POST['purpose']; 
      $in_time = $_POST['in_time']; 
      $out_time = $_POST['out_time'];

		$vehical_type = $_POST['vehical_type'];	  
      $vehical_number = $_POST['vehical_number'];
	      $visitor_id = $_POST['visitor_id'];
	  
	  $meeting_person = $_POST['meeting_person'];
	  
	  $up_file=$_FILES["id_proof"]["name"];
        move_uploaded_file($_FILES["id_proof"]["tmp_name"],"upload/".$up_file);
	  
     $sql = "INSERT INTO visitor_details (visitor_name, mobile, purpose, id_proof, meeting_person,in_time,out_time,vehical_type,vehical_number,visitor_id)
     VALUES ('$visitor_name','$mobile','$purpose','$up_file','$meeting_person','$in_time','$out_time','$vehical_type','$vehical_number','$visitor_id' )";
 
     if (mysqli_query($conn, $sql)) {
        echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "New User Added", "success", {
                        button: "Continue",
                            });
                        });
                        </script>';
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
	 

	
     mysqli_close($conn);
	  //echo '<script>location.href="order.php";</script>';

?>



