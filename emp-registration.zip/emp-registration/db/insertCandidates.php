<?php


    $candidate_name = $_POST['candidate_name'];
    $mobile = $_POST['mobile'];	 
     $technology = $_POST['technology'];
	 $email = $_POST['email'];
	 $category = $_POST['category'];
	 $location = $_POST['location'];
	 $id_number = $_POST['id_number'];
	 $experience = $_POST['experience'];
	 	
	  $in_time = $_POST['in_time'];
	 $out_time = $_POST['out_time'];
	  $schdule_name = $_POST['schdule_name'];
	  
	  $vehical = $_POST['vehical'];
	  
	  $vehical_number = $_POST['vehical_number'];
	  
	    $up_file=$_FILES["id_proof"]["name"];
        move_uploaded_file($_FILES["id_proof"]["tmp_name"],"upload/".$up_file);
	  
     $sql = "INSERT INTO interview_candidates (candidate_name, email,mobile, technology,category,location, id_proof,id_number, in_time,out_time, schdule_name,experience,vehical,vehical_number)
     VALUES ('$candidate_name','$email','$mobile','$technology','$category','$location','$up_file','$id_number','$in_time','$out_time','$schdule_name','$experience','$vehical','$vehical_number')";
 
     if (mysqli_query($conn, $sql)) {
        echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "New User Added", "success", {
                        button: "Continue",
                            });
                        });
                        </script>';
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
	  //echo '<script>location.href="order.php";</script>';

?>



