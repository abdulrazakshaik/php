<?php

 $servername='localhost';
    $username='root';
    $password='';
    $dbname = "employee_registration";
    $conn=mysqli_connect($servername,$username,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
		
		
		
    session_start();
   if($_SESSION['username']==""){
     include_once'inc/404.php';
   }else{
     if($_SESSION['role']=="Admin"){
       include_once'inc/header_all.php';
     }else{
         include_once'inc/header_all_operator.php';
     }
   }

 
if(isset($_POST['save_order'])){    
     $lot_no = $_POST['lot_no'];
      $cus_name = $_POST['cus_name'];	 
      $cus_vill = $_POST['cus_vill'];
	  $cus_mandl = $_POST['cus_mandl'];
	  $no_yards = $_POST['no_yards'];
	  $seed_variety = $_POST['seed_variety'];
	  $bag_cost = $_POST['bag_cost'];
	  $net_weight = $_POST['net_weight'];
	  $no_bags = $_POST['no_bags'];
	  $total_weight = $_POST['total_weight'];
	  $seed_process = $_POST['seed_process'];
	  $total_amount = $_POST['total_amount'];
	  $hamali_cost = $_POST['hamali_cost'];
	  $harvester_cost = $_POST['harvester_cost'];
	  $roaing_cost = $_POST['roaing_cost'];
	  $fertilization_cost = $_POST['fertilization_cost'];
	  $other_cost = $_POST['other_cost'];
	  $finel_amount = $_POST['finel_amount'];
 
     $sql = "INSERT INTO ticket_details (lot_no, cus_name, cus_vill, cus_mandl, no_yards, seed_variety, bag_cost, net_weight, no_bags, total_weight, seed_process, total_amount, hamali_cost, harvester_cost, roaing_cost, fertilization_cost, other_cost, finel_amount)
     VALUES ('$lot_no', '$cus_name', '$cus_vill', '$cus_mandl', '$no_yards', '$seed_variety', '$bag_cost', '$net_weight', '$no_bags', '$total_weight', '$seed_process', '$total_amount', '$hamali_cost', '$harvester_cost', '$roaing_cost', '$fertilization_cost', '$other_cost', '$finel_amount')";
 
     if (mysqli_query($conn, $sql)) {
        echo'<script type="text/javascript">
                        jQuery(function validation(){
                        swal("Success", "New User Added", "success", {
                        button: "Continue",
                            });
                        });
                        </script>';
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
	  //echo '<script>location.href="order.php";</script>';
}
 
	
	
	 

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Transaction
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
          <form action="" method="POST">
            <div class="box-body">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Officer Name</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-user"></i>
                    </div>
                    <input type="text" class="form-control pull-right" name="cashier_name" value="<?php echo $_SESSION['username']; ?>" readonly>
                  </div>
                  <!-- /.input group -->
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Transaction date</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <input type="text" class="form-control pull-right" name="orderdate" value="<?php echo date("d-m-Y");?>" readonly
                    data-date-format="yyyy-mm-dd">
                  </div>
                  <!-- /.input group -->
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Transaction Hours</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-clock-o"></i>
                    </div>
                    <input type="text" class="form-control pull-right" name="timeorder" value="<?php echo date('H:i') ?>" readonly>
                  </div>
                  <!-- /.input group -->
                </div>
              </div>
            </div>
			
			<div class="box-body">
			
              <div class="col-md-12">
			  <h4>Extra Charges</h4>
			  <br>
			   <div class="form-group col-md-3">
                  <label>Lot No</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>No</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="lot_no" id="lot_no" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Customer Name</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Name</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="cus_name" id="cus_name" required>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group col-md-3">
                  <label>Customer Village</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Village</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="cus_vill" id="cus_vill" required>
                  </div>
                  <!-- /.input group -->
                </div>
				<div class="form-group col-md-3">
                  <label>Customer Mandal</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Mandal</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="cus_mandl" id="cus_mandl" required>
                  </div>
                  <!-- /.input group -->
                </div>
               
              </div>
            </div>
            <div class="box-body">
              <div class="col-md-12">


				<div class="form-group col-md-3">
                  <label>No of yards</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Land</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="no_yards" id="no_yards" required >
                  </div>
                  <!-- /.input group -->
                </div>

	
			   <div class="form-group col-md-3">
                  <label>Seed variety</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>variety</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="seed_variety" id="seed_variety" required>
                  </div>
                  <!-- /.input group -->
                </div>

				<div class="form-group col-md-3">
                  <label>Bag Cost(1 Kg)</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Rs</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="bag_cost" id="bag_cost" required>
                  </div>
                  <!-- /.input group -->
                </div>
				
				 
				
				 <div class="form-group col-md-3">
                  <label>Net Weight(kg)</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Kg</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="net_weight" id="net_weight" required>
                  </div>
                  <!-- /.input group -->
                </div>			
                          
				
               
              </div>
            </div>
			 <div class="box-body">
              <div class="col-md-12">	

					<div class="form-group col-md-3">
                  <label>No Of Bags(kg)</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Kg</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="no_bags" id="no_bags" required>
                  </div>
                  <!-- /.input group -->
                </div> 		  
                 <div class="form-group col-md-3">
                  <label>Total Weight(kg)</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Kg</span>
                    </div>
                    <input type="text"  class="form-control pull-right" name="total_weight" id="total_weight" readonly>
                  </div>
                  <!-- /.input group -->
                </div>		
		
                <div class="form-group col-md-3">
                  <label>Seed Proccesing(kg)</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Kg</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="seed_process" id="seed_process" readonly >
                  </div>
                  <!-- /.input group -->
                </div>		
		   
               

				<div class="form-group col-md-3">
                  <label>Total Cost</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Rs</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="total_amount" id="total_amount" readonly required>
                  </div>
                  <!-- /.input group -->
                </div>               
              </div>
            </div>		

			<div class="box-body">			
              <div class="col-md-12">
			  <h4>Extra Charges</h4>
			  <br>
			   <div class="form-group col-md-3">
                  <label>Hamali Cost</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Rs</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="hamali_cost" id="hamali_cost" required>
                  </div>
                  <!-- /.input group -->
                </div>

                <div class="form-group col-md-3">
                  <label>Harvester Cost</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Rs</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="harvester_cost" id="harvester_cost" required>
                  </div>
                  <!-- /.input group -->
                </div>

                <div class="form-group col-md-3">
                  <label>Roaing Cost</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Rs</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="roaing_cost" id="roaing_cost" required>
                  </div>
                  <!-- /.input group -->
                </div>

				<div class="form-group col-md-3">
                  <label>Fertilization Cost</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Rs</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="fertilization_cost" id="fertilization_cost" required>
                  </div>
                  <!-- /.input group -->
                </div>               
              </div>
            </div>   


				<div class="box-body">			
              <div class="col-md-12">			  
			   <div class="form-group col-md-3">
                  <label>Other Charges</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Rs</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="other_cost" id="other_cost" required>
                  </div>
                  <!-- /.input group -->
                </div>

                <div class="form-group col-md-3">
                  <label>Total Amount</label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <span>Rs</span>
                    </div>
                    <input type="text" class="form-control pull-right" name="finel_amount" id="finel_amount" readonly>
                  </div>
                  <!-- /.input group -->
                </div>
 
              </div>
            </div>      
			<br><br>
			
            <div class="box-footer" align="center">
              <input type="submit" name="save_order" value="Save Transaction" class="btn btn-success">
              <a href="order.php" class="btn btn-warning">Back</a>
            </div>
          </form>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<script>
window.onload = function() {
	var finalAmount;
	var dummy,hamali_cost,harvester_cost,roaing_cost,fertilization_cost,other_cost,finel_amount;
    var bags = document.getElementById("no_bags"),
		weight = document.getElementById("net_weight"),
		respectedOutput = document.getElementById("total_weight"),
		bagcost = document.getElementById("bag_cost"),
        totalamount = document.getElementById("total_amount"),
		seedprocess = document.getElementById("seed_process");
		hamali_cost = document.getElementById("hamali_cost");
		harvester_cost = document.getElementById("harvester_cost");
		roaing_cost = document.getElementById("roaing_cost");
		fertilization_cost = document.getElementById("fertilization_cost");
		other_cost = document.getElementById("other_cost");
		finel_amount = document.getElementById("finel_amount");
		

		weight.addEventListener('input', function() {
			respectedOutput.value = 0;
			seedprocess.value = 0;
			totalamount.value = 0;
			bags.value = 0;
			if(weight.value != NULL && bags.value != NULL){
				respectedOutput.value = weight.value - bags.value;
				seedprocess.value = respectedOutput.value - ((weight.value - bags.value) / 100) * 10;
				finalAmount = seedprocess.value;
				dummy = bagcost.value;
				totalamount.value = finalAmount * dummy;
				
			}
			
		});

		bags.addEventListener('input', function() {
			respectedOutput.value = 0;
			seedprocess.value = 0;
			totalamount.value = 0;
			
        respectedOutput.value = weight.value - bags.value;
		seedprocess.value = respectedOutput.value - ((weight.value - bags.value) / 100) * 10;
		finalAmount = seedprocess.value;
		dummy = bagcost.value;
		totalamount.value = finalAmount * dummy;
		});
		
		other_cost.addEventListener('input', function() {
		finel_amount.value = Number(totalamount.value) - (Number(hamali_cost.value) + Number(harvester_cost.value) + Number(roaing_cost.value) + Number(fertilization_cost.value) + Number(other_cost.value));
		});
		
}
</script>

  <script>
  //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  
  </script>


 <?php
    include_once'inc/footer_all.php';
 ?>